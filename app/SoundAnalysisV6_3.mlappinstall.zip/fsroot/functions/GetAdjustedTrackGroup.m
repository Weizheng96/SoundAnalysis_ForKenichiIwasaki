function TrackGroup_adjusted=GetAdjustedTrackGroup(TrackGroup,StartFre)
TrackGroup_adjusted=cell(size(TrackGroup));
for TrackCnt=1:length(TrackGroup)
    Track=TrackGroup{TrackCnt};
    Track(2,:)=Track(2,:)+StartFre;
    TrackGroup_adjusted{TrackCnt}=Track;
end

end