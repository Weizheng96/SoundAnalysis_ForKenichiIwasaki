function [StartTime,EndTime,Spectrum_2x_bi_clean]=GetStartAndEndTime(Spectrum_2x)

%% smooth
% Spectrum_2x=imgaussfilt(Spectrum_2x,[3 5]);
%% Clean noise
LengthThres=100;
Spectrum_2x_bi=Spectrum_2x>3;
Spectrum_2x_bi_clean=RemoveComponentSmallerThan_2D(Spectrum_2x_bi,LengthThres);
CC_Spectrum = bwconncomp(Spectrum_2x_bi_clean);
%% Find largest CC
if CC_Spectrum.NumObjects>0
    for CCcnt=1:CC_Spectrum.NumObjects
        lst=CC_Spectrum.PixelIdxList{CCcnt};
        L(CCcnt)=sum(Spectrum_2x(lst));
    end
    [~,CCidx]=max(L);
    lst=CC_Spectrum.PixelIdxList{CCidx};
    if mean(Spectrum_2x(lst))<5
        StartTime=0;
        EndTime=0;
    else
        [~,StartTime]=ind2sub(CC_Spectrum.ImageSize,min(lst));
        [~,EndTime]=ind2sub(CC_Spectrum.ImageSize,max(lst));
    end
else
    StartTime=0;
    EndTime=0;
end
