function dBSPL=RMS2dBSPL(RMS)

dBSPL=20*log10(RMS)+35;

end