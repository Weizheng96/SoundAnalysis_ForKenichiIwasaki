function [parameters,RMSEachPeak]=GetParameters(TrackGroup_adjusted,SpectrumAlongTime_normalize,RMS)
% colorSequence=["r","m","g","w"];
% imagesc(SpectrumAlongTime_normalize);
% hold on;
parameters=[];
RMSEachPeak=zeros(length(TrackGroup_adjusted),10);
for TrackCnt=1:length(TrackGroup_adjusted)
    ThisTrackFum=TrackGroup_adjusted{TrackCnt};
    Time=ThisTrackFum(1,:); FumFre=ThisTrackFum(2,:);
    peakNum=0;
    for peakCnt=1:10
        ThisFre=round(FumFre*peakCnt);
        if max(ThisFre)>2000
            break;
        end
        idx=sub2ind(size(SpectrumAlongTime_normalize),ThisFre,Time);
        PeakMeanZ=mean(SpectrumAlongTime_normalize(idx));
        if PeakMeanZ>5 || peakCnt==1
%             plot(Time,ThisFre,colorSequence(mod(TrackCnt,length(colorSequence))+1)...
%                 ,'LineWidth',3);
            RMSEachPeak(TrackCnt,peakCnt)=mean(RMS(idx));
            peakNum=peakNum+1;
        else
            RMSEachPeak(TrackCnt,peakCnt)=nan;
        end
    end
    parameters(TrackCnt,1)=Time(1)/100;% start time
    parameters(TrackCnt,2)=Time(end)/100;% end time
    parameters(TrackCnt,3)=(Time(end)-Time(1))/100;% duration
    parameters(TrackCnt,4)=peakNum; % peak number
    parameters(TrackCnt,5)=mean(FumFre); % F0 average;
    parameters(TrackCnt,6)=std(FumFre); % F0 std
    idx_vertical=~((Time(2:end)-Time(1:end-1))==0);
    parameters(TrackCnt,7)=mean(abs(gradient(FumFre(idx_vertical))))*100; %F0 speed
    parameters(TrackCnt,8)=max(FumFre)-FumFre(1); %F0 max-start
    parameters(TrackCnt,9)=max(FumFre)-FumFre(end); %F0 max-end
end

end