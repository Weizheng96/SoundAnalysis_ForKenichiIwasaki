function [P1,f,freUint]=FFTparameter(y_sample,Fs)
L=length(y_sample);
Y_sample=fft(y_sample);
P2 = abs(Y_sample/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = Fs*(0:(L/2))/L;
freUint=f(2);
end